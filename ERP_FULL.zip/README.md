
# ERP Offline — Solutions Segurança e Tecnologia (FULL)

This starter contains the full skeleton with the modules produced: Clients, Products/Inventory, Orders of Service, Schedule, Finance, Quotes, Dashboard, Contracts, Users, NF-e, Billing, Reports, Backup & Sync placeholders and more.

## How to run (developer)
1. Install dependencies: `npm install`
2. Run in dev: `npm run dev`

This is a skeleton intended as a starting point. Replace `*` versions in package.json with real versions before installing.
